﻿CREATE OR ALTER VIEW [dbo].[VL_Lecture_Details] AS

WITH StaffDates AS (
    SELECT Lecture_Date, Teacher_Code FROM W_Lecture_Actual
    UNION
    SELECT Lecture_Date, Teacher_Code FROM W_Business_Actual
    UNION
    SELECT Lecture_Date, Teacher_Code FROM W_Business_No_Punch
    UNION
    SELECT Lecture_Date, Staff_Code As Teacher_Code FROM W_Stamp_Data
),

-- A/B/C の行番号付け（開始時間昇順）
ARows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY Lecture_Date, Teacher_Code ORDER BY Start_Time) AS RN
    FROM W_Lecture_Actual WHERE Phase=2 And Data_Type=1
),
BRows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY Lecture_Date, Teacher_Code ORDER BY Start_Time) AS RN
    FROM W_Business_Actual
),
CRows AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY Lecture_Date, Teacher_Code ORDER BY Start_Time) AS RN
    FROM W_Business_No_Punch
),

-- A/B/C の最小開始・最大終了
AMinMax AS (
    SELECT Lecture_Date, Teacher_Code, 
           MIN(Start_Time) AS AMinStart,
           MAX(End_Time)   AS AMaxEnd
    FROM W_Lecture_Actual GROUP BY Teacher_Code, Lecture_Date
),
BMinMax AS (
    SELECT Lecture_Date, Teacher_Code, 
           MIN(Start_Time) AS BMinStart,
           MAX(End_Time)   AS BMaxEnd
    FROM W_Business_Actual GROUP BY Teacher_Code, Lecture_Date
),
CMinMax AS (
    SELECT Lecture_Date, Teacher_Code, 
           MIN(Start_Time) AS CMinStart,
           MAX(End_Time)   AS CMaxEnd
    FROM W_Business_No_Punch GROUP BY Teacher_Code, Lecture_Date
),


Coefficient AS (
    SELECT
        Year
        , Half_Year
        , Site_Code
        , Grade
        , Class_Code
        , Lecture_Coefficient
        , Remarks
    FROM
        M_Lecture_Wage_Percentage 
    WHERE
        1 = 1 
),


-- A/B/C の横展開（最大 10 件）
AExpanded AS (
    SELECT 
        r.Lecture_Date As A_Lecture_Date, 
        r.Teacher_Code As A_Teacher_Code,
        MAX(CASE WHEN RN=1 THEN r.Site_Code END) AS Site_Code1,
        MAX(CASE WHEN RN=1 THEN r.Grade END) AS Grade1,
        MAX(CASE WHEN RN=1 THEN r.Class_Code END) AS Class_Code1,
        MAX(CASE WHEN RN=1 THEN r.Koma_Seq END) AS Koma_Seq1,
        MAX(CASE WHEN RN=1 THEN r.Pinch_Type END) AS Pinch_Type1,
        MAX(CASE WHEN RN=1 THEN r.Start_Time END) AS Start_Time1,
        MAX(CASE WHEN RN=1 THEN r.End_Time END) AS End_Time1,
        MAX(CASE WHEN RN=1 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient1,
        MAX(CASE WHEN RN=1 THEN cf.Remarks END) AS Remarks1,
        MAX(CASE WHEN RN=1 THEN te.Amount END) AS Amount1,
        MAX(CASE WHEN RN=2 THEN r.Site_Code END) AS Site_Code2,
        MAX(CASE WHEN RN=2 THEN r.Grade END) AS Grade2,
        MAX(CASE WHEN RN=2 THEN r.Class_Code END) AS Class_Code2,
        MAX(CASE WHEN RN=2 THEN r.Koma_Seq END) AS Koma_Seq2,
        MAX(CASE WHEN RN=2 THEN r.Pinch_Type END) AS Pinch_Type2,
        MAX(CASE WHEN RN=2 THEN r.Start_Time END) AS Start_Time2,
        MAX(CASE WHEN RN=2 THEN r.End_Time END) AS End_Time2,
        MAX(CASE WHEN RN=2 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient2,
        MAX(CASE WHEN RN=2 THEN cf.Remarks END) AS Remarks2,
        MAX(CASE WHEN RN=2 THEN te.Amount END) AS Amount2,
        MAX(CASE WHEN RN=3 THEN r.Site_Code END) AS Site_Code3,
        MAX(CASE WHEN RN=3 THEN r.Grade END) AS Grade3,
        MAX(CASE WHEN RN=3 THEN r.Class_Code END) AS Class_Code3,
        MAX(CASE WHEN RN=3 THEN r.Koma_Seq END) AS Koma_Seq3,
        MAX(CASE WHEN RN=3 THEN r.Pinch_Type END) AS Pinch_Type3,
        MAX(CASE WHEN RN=3 THEN r.Start_Time END) AS Start_Time3,
        MAX(CASE WHEN RN=3 THEN r.End_Time END) AS End_Time3,
        MAX(CASE WHEN RN=3 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient3,
        MAX(CASE WHEN RN=3 THEN cf.Remarks END) AS Remarks3,
        MAX(CASE WHEN RN=3 THEN te.Amount END) AS Amount3,
        MAX(CASE WHEN RN=4 THEN r.Site_Code END) AS Site_Code4,
        MAX(CASE WHEN RN=4 THEN r.Grade END) AS Grade4,
        MAX(CASE WHEN RN=4 THEN r.Class_Code END) AS Class_Code4,
        MAX(CASE WHEN RN=4 THEN r.Koma_Seq END) AS Koma_Seq4,
        MAX(CASE WHEN RN=4 THEN r.Pinch_Type END) AS Pinch_Type4,
        MAX(CASE WHEN RN=4 THEN r.Start_Time END) AS Start_Time4,
        MAX(CASE WHEN RN=4 THEN r.End_Time END) AS End_Time4,
        MAX(CASE WHEN RN=4 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient4,
        MAX(CASE WHEN RN=4 THEN cf.Remarks END) AS Remarks4,
        MAX(CASE WHEN RN=4 THEN te.Amount END) AS Amount4,
        MAX(CASE WHEN RN=5 THEN r.Site_Code END) AS Site_Code5,
        MAX(CASE WHEN RN=5 THEN r.Grade END) AS Grade5,
        MAX(CASE WHEN RN=5 THEN r.Class_Code END) AS Class_Code5,
        MAX(CASE WHEN RN=5 THEN r.Koma_Seq END) AS Koma_Seq5,
        MAX(CASE WHEN RN=5 THEN r.Pinch_Type END) AS Pinch_Type5,
        MAX(CASE WHEN RN=5 THEN r.Start_Time END) AS Start_Time5,
        MAX(CASE WHEN RN=5 THEN r.End_Time END) AS End_Time5,
        MAX(CASE WHEN RN=5 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient5,
        MAX(CASE WHEN RN=5 THEN cf.Remarks END) AS Remarks5,
        MAX(CASE WHEN RN=5 THEN te.Amount END) AS Amount5,
        MAX(CASE WHEN RN=6 THEN r.Site_Code END) AS Site_Code6,
        MAX(CASE WHEN RN=6 THEN r.Grade END) AS Grade6,
        MAX(CASE WHEN RN=6 THEN r.Class_Code END) AS Class_Code6,
        MAX(CASE WHEN RN=6 THEN r.Koma_Seq END) AS Koma_Seq6,
        MAX(CASE WHEN RN=6 THEN r.Pinch_Type END) AS Pinch_Type6,
        MAX(CASE WHEN RN=6 THEN r.Start_Time END) AS Start_Time6,
        MAX(CASE WHEN RN=6 THEN r.End_Time END) AS End_Time6,
        MAX(CASE WHEN RN=6 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient6,
        MAX(CASE WHEN RN=6 THEN cf.Remarks END) AS Remarks6,
        MAX(CASE WHEN RN=6 THEN te.Amount END) AS Amount6,
        MAX(CASE WHEN RN=7 THEN r.Site_Code END) AS Site_Code7,
        MAX(CASE WHEN RN=7 THEN r.Grade END) AS Grade7,
        MAX(CASE WHEN RN=7 THEN r.Class_Code END) AS Class_Code7,
        MAX(CASE WHEN RN=7 THEN r.Koma_Seq END) AS Koma_Seq7,
        MAX(CASE WHEN RN=7 THEN r.Pinch_Type END) AS Pinch_Type7,
        MAX(CASE WHEN RN=7 THEN r.Start_Time END) AS Start_Time7,
        MAX(CASE WHEN RN=7 THEN r.End_Time END) AS End_Time7,
        MAX(CASE WHEN RN=7 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient7,
        MAX(CASE WHEN RN=7 THEN cf.Remarks END) AS Remarks7,
        MAX(CASE WHEN RN=7 THEN te.Amount END) AS Amount7,
        MAX(CASE WHEN RN=8 THEN r.Site_Code END) AS Site_Code8,
        MAX(CASE WHEN RN=8 THEN r.Grade END) AS Grade8,
        MAX(CASE WHEN RN=8 THEN r.Class_Code END) AS Class_Code8,
        MAX(CASE WHEN RN=8 THEN r.Koma_Seq END) AS Koma_Seq8,
        MAX(CASE WHEN RN=8 THEN r.Pinch_Type END) AS Pinch_Type8,
        MAX(CASE WHEN RN=8 THEN r.Start_Time END) AS Start_Time8,
        MAX(CASE WHEN RN=8 THEN r.End_Time END) AS End_Time8,
        MAX(CASE WHEN RN=8 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient8,
        MAX(CASE WHEN RN=8 THEN cf.Remarks END) AS Remarks8,
        MAX(CASE WHEN RN=8 THEN te.Amount END) AS Amount8,
        MAX(CASE WHEN RN=9 THEN r.Site_Code END) AS Site_Code9,
        MAX(CASE WHEN RN=9 THEN r.Grade END) AS Grade9,
        MAX(CASE WHEN RN=9 THEN r.Class_Code END) AS Class_Code9,
        MAX(CASE WHEN RN=9 THEN r.Koma_Seq END) AS Koma_Seq9,
        MAX(CASE WHEN RN=9 THEN r.Pinch_Type END) AS Pinch_Type9,
        MAX(CASE WHEN RN=9 THEN r.Start_Time END) AS Start_Time9,
        MAX(CASE WHEN RN=9 THEN r.End_Time END) AS End_Time9,
        MAX(CASE WHEN RN=9 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient9,
        MAX(CASE WHEN RN=9 THEN cf.Remarks END) AS Remarks9,
        MAX(CASE WHEN RN=9 THEN te.Amount END) AS Amount9,
        MAX(CASE WHEN RN=10 THEN r.Site_Code END) AS Site_Code10,
        MAX(CASE WHEN RN=10 THEN r.Grade END) AS Grade10,
        MAX(CASE WHEN RN=10 THEN r.Class_Code END) AS Class_Code10,
        MAX(CASE WHEN RN=10 THEN r.Koma_Seq END) AS Koma_Seq10,
        MAX(CASE WHEN RN=10 THEN r.Pinch_Type END) AS Pinch_Type10,
        MAX(CASE WHEN RN=10 THEN r.Start_Time END) AS Start_Time10,
        MAX(CASE WHEN RN=10 THEN r.End_Time END) AS End_Time10,
        MAX(CASE WHEN RN=10 THEN COALESCE(cf.Lecture_Coefficient, 1.000) END) AS Lecture_Coefficient10,
        MAX(CASE WHEN RN=10 THEN cf.Remarks END) AS Remarks10,
        MAX(CASE WHEN RN=10 THEN te.Amount END) AS Amount10

    FROM ARows r

        OUTER APPLY (
           SELECT
                Year
                , Half_Year
                , '0' As Seasonal_Period
                , Site_Code
                , Grade
                , Class_Code
                , Lecture_Coefficient
                , Remarks
            FROM
                M_Lecture_Wage_Percentage 
            WHERE
                1=1
                AND r.Course_Type = 0
                AND Year = CASE 
                    WHEN MONTH(r.Lecture_Date) = 1 THEN YEAR(r.Lecture_Date) - 1
                    ELSE YEAR(r.Lecture_Date)
                END
                AND Half_Year = (
                    CASE 
                        WHEN MONTH(r.Lecture_Date) BETWEEN 2 AND 7 THEN 1 
                        WHEN MONTH(r.Lecture_Date) >= 8 OR MONTH(r.Lecture_Date) = 1 THEN 2 
                    END
                )
                AND r.Grade = Grade
                AND SUBSTRING(r.Class_Code, 1, 1) = Class_Code
                AND (
                    (Site_Code != 'ZZ' AND r.Site_Code = Site_Code)
                    OR (Site_Code = 'ZZ')
                )
           UNION ALL
           SELECT
                Year
                , '0' As Half_Year
                , Seasonal_Period
                , Site_Code
                , Grade
                , Class_Code
                , Lecture_Coefficient
                , Remarks
            FROM
                M_Lecture_Wage_Percentage_Course 
            WHERE
                1=1
                AND r.Course_Type > 0 
                AND Year = CASE 
                    WHEN MONTH(r.Lecture_Date) = 1 THEN YEAR(r.Lecture_Date) - 1
                    ELSE YEAR(r.Lecture_Date)
                END
                AND Seasonal_Period = r.Course_Type 
                AND r.Grade = Grade
                AND SUBSTRING(r.Class_Code, 1, 1) = Class_Code
                AND (
                    (Site_Code != 'ZZ' AND r.Site_Code = Site_Code)
                    OR (Site_Code = 'ZZ')
                )
            ) cf
 
        OUTER APPLY (
            SELECT TOP 1
                Amount
                , Effective_Date
                , Teacher_Code
                , Site_Code
            FROM 
                M_Transpo_Expenses
            WHERE
                Effective_Date <= r.Lecture_Date
                AND Teacher_Code = r.Teacher_Code
                AND Site_Code = r.Site_Code
            ORDER BY
                Effective_Date DESC
        ) te
    GROUP BY r.Lecture_Date, r.Teacher_Code
),
BExpanded AS (
    SELECT 
        Lecture_Date As B_Lecture_Date, 
        Teacher_Code As B_Teacher_Code,
        MAX(CASE WHEN RN=1 THEN Site_Code END) AS Task_Site_Code1,
        MAX(CASE WHEN RN=1 THEN Start_Time END) AS Task_Start_Time1,
        MAX(CASE WHEN RN=1 THEN End_Time END) AS Task_End_Time1,
        MAX(CASE WHEN RN=2 THEN Site_Code END) AS Task_Site_Code2,
        MAX(CASE WHEN RN=2 THEN Start_Time END) AS Task_Start_Time2,
        MAX(CASE WHEN RN=2 THEN End_Time END) AS Task_End_Time2,
        MAX(CASE WHEN RN=3 THEN Site_Code END) AS Task_Site_Code3,
        MAX(CASE WHEN RN=3 THEN Start_Time END) AS Task_Start_Time3,
        MAX(CASE WHEN RN=3 THEN End_Time END) AS Task_End_Time3,
        MAX(CASE WHEN RN=4 THEN Site_Code END) AS Task_Site_Code4,
        MAX(CASE WHEN RN=4 THEN Start_Time END) AS Task_Start_Time4,
        MAX(CASE WHEN RN=4 THEN End_Time END) AS Task_End_Time4,
        MAX(CASE WHEN RN=5 THEN Site_Code END) AS Task_Site_Code5,
        MAX(CASE WHEN RN=5 THEN Start_Time END) AS Task_Start_Time5,
        MAX(CASE WHEN RN=5 THEN End_Time END) AS Task_End_Time5,
        MAX(CASE WHEN RN=6 THEN Site_Code END) AS Task_Site_Code6,
        MAX(CASE WHEN RN=6 THEN Start_Time END) AS Task_Start_Time6,
        MAX(CASE WHEN RN=6 THEN End_Time END) AS Task_End_Time6
    FROM BRows
    GROUP BY Lecture_Date, Teacher_Code
),
CExpanded AS (
    SELECT 
        r.Lecture_Date As C_Lecture_Date, 
        r.Teacher_Code As C_Teacher_Code,
        MAX(CASE WHEN RN=1 THEN r.Site_Code END) AS Others_Site_Code1,
        MAX(CASE WHEN RN=1 THEN r.Start_Time END) AS Others_Start_Time1,
        MAX(CASE WHEN RN=1 THEN r.End_Time END) AS Others_End_Time1,
        MAX(CASE WHEN RN=1 THEN r.Transp_Expens_Flag END) AS Others_Transp_Expens_Flag1,
        MAX(CASE WHEN RN=1 AND r.Transp_Expens_Flag=1 THEN te.Amount ELSE NULL END) AS Others_Amount1,
        MAX(CASE WHEN RN=2 THEN r.Site_Code END) AS Others_Site_Code2,
        MAX(CASE WHEN RN=2 THEN r.Start_Time END) AS Others_Start_Time2,
        MAX(CASE WHEN RN=2 THEN r.End_Time END) AS Others_End_Time2,
        MAX(CASE WHEN RN=2 THEN r.Transp_Expens_Flag END) AS Others_Transp_Expens_Flag2,
        MAX(CASE WHEN RN=2 AND r.Transp_Expens_Flag=1 THEN te.Amount ELSE NULL END) AS Others_Amount2,
        MAX(CASE WHEN RN=3 THEN r.Site_Code END) AS Others_Site_Code3,
        MAX(CASE WHEN RN=3 THEN r.Start_Time END) AS Others_Start_Time3,
        MAX(CASE WHEN RN=3 THEN r.End_Time END) AS Others_End_Time3,
        MAX(CASE WHEN RN=3 THEN r.Transp_Expens_Flag END) AS Others_Transp_Expens_Flag3,
        MAX(CASE WHEN RN=3 AND r.Transp_Expens_Flag=1 THEN te.Amount ELSE NULL END) AS Others_Amount3,
        MAX(CASE WHEN RN=4 THEN r.Site_Code END) AS Others_Site_Code4,
        MAX(CASE WHEN RN=4 THEN r.Start_Time END) AS Others_Start_Time4,
        MAX(CASE WHEN RN=4 THEN r.End_Time END) AS Others_End_Time4,
        MAX(CASE WHEN RN=4 THEN r.Transp_Expens_Flag END) AS Others_Transp_Expens_Flag4,
        MAX(CASE WHEN RN=4 AND r.Transp_Expens_Flag=1 THEN te.Amount ELSE NULL END) AS Others_Amount4,
        MAX(CASE WHEN RN=5 THEN r.Site_Code END) AS Others_Site_Code5,
        MAX(CASE WHEN RN=5 THEN r.Start_Time END) AS Others_Start_Time5,
        MAX(CASE WHEN RN=5 THEN r.End_Time END) AS Others_End_Time5,
        MAX(CASE WHEN RN=5 THEN r.Transp_Expens_Flag END) AS Others_Transp_Expens_Flag5,
        MAX(CASE WHEN RN=5 AND r.Transp_Expens_Flag=1 THEN te.Amount ELSE NULL END) AS Others_Amount5,
        MAX(CASE WHEN RN=6 THEN r.Site_Code END) AS Others_Site_Code6,
        MAX(CASE WHEN RN=6 THEN r.Start_Time END) AS Others_Start_Time6,
        MAX(CASE WHEN RN=6 THEN r.End_Time END) AS Others_End_Time6,
        MAX(CASE WHEN RN=6 THEN r.Transp_Expens_Flag END) AS Others_Transp_Expens_Flag6,
        MAX(CASE WHEN RN=6 AND r.Transp_Expens_Flag=1 THEN te.Amount ELSE NULL END) AS Others_Amount6
    FROM CRows r
        OUTER APPLY (
            SELECT TOP 1
                Amount
                , Effective_Date
                , Teacher_Code
                , Site_Code
            FROM 
                M_Transpo_Expenses
            WHERE
                Effective_Date <= r.Lecture_Date
                AND Teacher_Code = r.Teacher_Code
                AND Site_Code = r.Site_Code
            ORDER BY
                Effective_Date DESC
        ) te
    GROUP BY r.Lecture_Date, r.Teacher_Code
),

-- 重複件数＋重複 ID（CSV）
OverlapDetails AS (
    SELECT
        s.Lecture_Date,
        s.Teacher_Code,

--         A-A
        (SELECT COUNT(*) FROM W_Lecture_Actual a1 JOIN W_Lecture_Actual a2
         ON a1.Teacher_Code=s.Teacher_Code AND a2.Teacher_Code=s.Teacher_Code
        AND a1.Lecture_Date=s.Lecture_Date AND a2.Lecture_Date=s.Lecture_Date
        AND a1.Phase='2' AND a2.Phase='2'
        AND a1.Data_Type=1 AND a2.Data_Type=1
        AND a1.Id<a2.Id AND a1.Start_Time<a2.End_Time AND a1.End_Time>a2.Start_Time) AS CntAA,

--         B-B
        (SELECT COUNT(*) FROM W_Business_Actual b1 JOIN W_Business_Actual b2
         ON b1.Teacher_Code=s.Teacher_Code AND b2.Teacher_Code=s.Teacher_Code
        AND b1.Lecture_Date=s.Lecture_Date AND b2.Lecture_Date=s.Lecture_Date
        AND b1.Id<b2.Id AND b1.Start_Time<b2.End_Time AND b1.End_Time>b2.Start_Time) AS CntBB,

--         C-C
        (SELECT COUNT(*) FROM W_Business_No_Punch c1 JOIN W_Business_No_Punch c2
         ON c1.Teacher_Code=s.Teacher_Code AND c2.Teacher_Code=s.Teacher_Code
        AND c1.Lecture_Date=s.Lecture_Date AND c2.Lecture_Date=s.Lecture_Date
        AND c1.Id<c2.Id AND c1.Start_Time<c2.End_Time AND c1.End_Time>c2.Start_Time) AS CntCC,

--         A-B
        (SELECT COUNT(*) FROM W_Lecture_Actual a JOIN W_Business_Actual b
         ON a.Teacher_Code=s.Teacher_Code AND b.Teacher_Code=s.Teacher_Code
        AND a.Lecture_Date=s.Lecture_Date AND b.Lecture_Date=s.Lecture_Date
        AND a.Start_Time<b.End_Time AND a.End_Time>b.Start_Time) AS CntAB,

--         A-C
        (SELECT COUNT(*) FROM W_Lecture_Actual a JOIN W_Business_No_Punch c
         ON a.Teacher_Code=s.Teacher_Code AND c.Teacher_Code=s.Teacher_Code
        AND a.Lecture_Date=s.Lecture_Date AND c.Lecture_Date=s.Lecture_Date
        AND a.Start_Time<c.End_Time AND a.End_Time>c.Start_Time) AS CntAC,

--         B-C
        (SELECT COUNT(*) FROM W_Business_Actual b JOIN W_Business_No_Punch c
         ON b.Teacher_Code=s.Teacher_Code AND c.Teacher_Code=s.Teacher_Code
        AND b.Lecture_Date=s.Lecture_Date AND c.Lecture_Date=s.Lecture_Date
        AND b.Start_Time<c.End_Time AND b.End_Time>c.Start_Time) AS CntBC,

--         M-C
        (SELECT COUNT(*) FROM W_Stamp_Data m JOIN W_Business_No_Punch c
         ON m.Staff_Code=s.Teacher_Code AND c.Teacher_Code=s.Teacher_Code
        AND m.Lecture_Date=s.Lecture_Date AND c.Lecture_Date=s.Lecture_Date
        AND m.Start_Time<c.End_Time AND m.End_Time>c.Start_Time) AS CntMC

    FROM StaffDates s
),

MainCheck AS (
    SELECT
        s.Lecture_Date,
        s.Teacher_Code,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1   -- 主テーブルが無い日は NG
            WHEN EXISTS (
                SELECT 1 FROM W_Lecture_Actual a
                WHERE a.Lecture_Date = s.Lecture_Date
                  AND a.Teacher_Code = s.Teacher_Code
                  AND a.Start_Time < m.Start_Time
            ) THEN 1 ELSE 0 
        END AS ABeforeStart,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Lecture_Actual a
                WHERE a.Lecture_Date = s.Lecture_Date
                  AND a.Teacher_Code = s.Teacher_Code
                  AND a.End_Time > m.End_Time
            ) THEN 1 ELSE 0 
        END AS AAfterEnd,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_Actual b
                WHERE b.Lecture_Date = s.Lecture_Date
                  AND b.Teacher_Code = s.Teacher_Code
                  AND b.Start_Time < m.Start_Time
            ) THEN 1 ELSE 0 
        END AS BBeforeStart,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_Actual b
                WHERE b.Lecture_Date = s.Lecture_Date
                  AND b.Teacher_Code = s.Teacher_Code
                  AND b.End_Time > m.End_Time
            ) THEN 1 ELSE 0 
        END AS BAfterEnd,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_No_Punch c
                WHERE c.Lecture_Date = s.Lecture_Date
                  AND c.Teacher_Code = s.Teacher_Code
                  AND c.Start_Time < m.Start_Time
            ) THEN 1 ELSE 0 
        END AS CBeforeStart,

        CASE 
            WHEN m.Staff_Code IS NULL THEN 1
            WHEN EXISTS (
                SELECT 1 FROM W_Business_No_Punch c
                WHERE c.Lecture_Date = s.Lecture_Date
                  AND c.Teacher_Code = s.Teacher_Code
                  AND c.End_Time > m.End_Time
            ) THEN 1 ELSE 0 
        END AS CAfterEnd

    FROM StaffDates s
    LEFT JOIN W_Stamp_Data m
        ON m.Staff_Code = s.Teacher_Code
       AND m.Lecture_Date = s.Lecture_Date
),
Teacher AS (
  SELECT
    [講師コード] As Teacher_Code
    , [講師名] As Teacher_Name
  FROM
    TeacherRegistry
  WHERE
    1=1
    AND [登録区分] IS NULL
    AND [専任] = '1'
)

SELECT
    s.Lecture_Date As Lecture_Date
    , s.Teacher_Code As Teacher_Code
    , mt.Teacher_Name As Teacher_Name

--     主テーブル
    , m.Start_Time AS Punch_Start_Time
    , m.End_Time   AS Punch_End_Time

--     A/B/C の最小開始・最大終了
    , amin.AMinStart As Lecture_Start_Time
    , amin.AMaxEnd As Lecture_End_Time
    , bmin.BMinStart As Task_Start_Time
    , bmin.BMaxEnd As Task_End_Time
    , cmin.CMinStart As Others_Start_Time
    , cmin.CMaxEnd As Others_End_Time

    , CONVERT(TIME(0), NULL) As Work_Start_Time
    , CONVERT(TIME(0), NULL) As Work_End_Time
    , CONVERT(TIME(0), NULL) As Deemed_Start_Time
    , CONVERT(TIME(0), NULL) As Deemed_End_Time

--     A/B/C 横並び 10 件
    , a.*
    , b.*
    , c.*

--     重複件数
    , o.CntAA As Overlap_Lecture
    , o.CntAB As Overlap_Task
    , o.CntMC As Overlap_Other

--     主テーブル整合性
--     主テーブル整合性チェック
    , mc.ABeforeStart
    , mc.AAfterEnd
    , mc.BBeforeStart
    , mc.BAfterEnd
    , mc.CBeforeStart
    , mc.CAfterEnd

    , HW.Deemed_Time_Before
    , HW.Deemed_Time_After
    , HW.Task_Base_Unit_Price
    , TW.Task_Unit_Price
    , TW.Lecture_Unit_Price
    , m.Punch_Count As Punch_Count
    , '' As Status
    , '' As TaskUnBreakTime

FROM StaffDates s
LEFT JOIN W_Stamp_Data m
    ON m.Staff_Code = s.Teacher_Code
   AND m.Lecture_Date = s.Lecture_Date
LEFT JOIN AMinMax amin
    ON amin.Teacher_Code = s.Teacher_Code
   AND amin.Lecture_Date = s.Lecture_Date
LEFT JOIN BMinMax bmin
    ON bmin.Teacher_Code = s.Teacher_Code
   AND bmin.Lecture_Date = s.Lecture_Date
LEFT JOIN CMinMax cmin
    ON cmin.Teacher_Code = s.Teacher_Code
   AND cmin.Lecture_Date = s.Lecture_Date
LEFT JOIN AExpanded a
    ON a.A_Teacher_Code = s.Teacher_Code
   AND a.A_Lecture_Date = s.Lecture_Date
LEFT JOIN BExpanded b
    ON b.B_Teacher_Code = s.Teacher_Code
   AND b.B_Lecture_Date = s.Lecture_Date
LEFT JOIN CExpanded c
    ON c.C_Teacher_Code = s.Teacher_Code
   AND c.C_Lecture_Date = s.Lecture_Date
LEFT JOIN OverlapDetails o
    ON o.Teacher_Code = s.Teacher_Code
   AND o.Lecture_Date = s.Lecture_Date
LEFT JOIN MainCheck mc
    ON mc.Teacher_Code = s.Teacher_Code
   AND mc.Lecture_Date = s.Lecture_Date
LEFT JOIN Teacher mt
    ON mt.Teacher_Code = s.Teacher_Code

-- [講師給与単価] コマ単価、業務給単価取得
OUTER APPLY (
  SELECT TOP 1
    Effective_Date
    , Teacher_Code
    , Lecture_Unit_Price
    , Task_Unit_Price
  FROM M_Teacher_Wage
  WHERE
    Teacher_Code = s.Teacher_Code
    AND Effective_Date <= s.Lecture_Date
  ORDER BY
    Effective_Date DESC
) TW

-- [業務給基本設定データ] 標準単価、みなし時間
OUTER APPLY (
  SELECT TOP 1
    Effective_Date
    , Task_Base_Unit_Price
    , Deemed_Time_Before
    , Deemed_Time_After
  FROM 
    M_Hourly_Wage
  WHERE
    Effective_Date <= s.Lecture_Date
  ORDER BY
    Effective_Date DESC
) HW
INNER JOIN Teacher TR
    ON (
        s.Teacher_Code=TR.Teacher_Code
    )
