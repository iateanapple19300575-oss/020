﻿''' <summary>
''' TimePattern Dto
''' </summary>
Public Class TimePatternDto

    ''' <summary>
    ''' 対象年月度
    ''' </summary>
    ''' <returns></returns>
    Public Property TargetDate As Date

    ''' <summary>
    ''' 時間割パターン一覧情報
    ''' </summary>
    Public Property DataList As New List(Of TimePatternDto)

    ''' <summary>
    ''' 年度
    ''' </summary>
    Public Property Year As String

    ''' <summary>
    ''' 年月日
    ''' </summary>
    Public Property LectureDate As String

    ''' <summary>
    ''' 曜日
    ''' </summary>
    Public Property Youbi As String

    ''' <summary>
    ''' 日程パターン名
    ''' </summary>
    Public Property SchedulePattern As String

    ''' <summary>
    ''' 作成日
    ''' </summary>
    Public Property CreateDate As DateTime?

    ''' <summary>
    ''' 作成者
    ''' </summary>
    Public Property CreateUser As String

    ''' <summary>
    ''' 更新日
    ''' </summary>
    Public Property UpdateDate As DateTime?

    ''' <summary>
    ''' 更新者
    ''' </summary>
    Public Property UpdateUser As String


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    Public Sub New()
        Clear()
    End Sub

    ''' <summary>
    ''' TimePatternEntity の初期化
    ''' </summary>
    Public Sub Clear()
        Year = ""
        LectureDate = Nothing
        Youbi = Nothing
        SchedulePattern = ""
        CreateDate = Nothing
        CreateUser = ""
        UpdateDate = Nothing
        UpdateUser = ""
    End Sub
End Class
