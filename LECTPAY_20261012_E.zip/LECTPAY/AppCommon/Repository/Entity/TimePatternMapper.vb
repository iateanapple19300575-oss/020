﻿''' <summary>
''' Entity ⇔ Dto Mapper：TimePattern
''' </summary>
Public Class TimePatternMapper

    ''' <summary>
    ''' Entity → DTO 変換
    ''' TimePatternEntity → TimePatternDto
    ''' </summary>
    Public Shared Function ToDto(ByVal e As List(Of TimePatternEntity)) As List(Of TimePatternDto)
        Dim result As New List(Of TimePatternDto)
        For i As Integer = 0 To e.Count - 1
            Dim d As New TimePatternDto()
            d.Year = e(i).Year
            d.LectureDate = e(i).LectureDate
            d.Youbi = e(i).Youbi
            d.SchedulePattern = e(i).SchedulePattern
            d.CreateDate = e(i).CreateDate
            d.CreateUser = e(i).CreateUser
            d.UpdateDate = e(i).UpdateDate
            d.UpdateUser = e(i).UpdateUser
            result.Add(d)
        Next
        Return result
    End Function

    ''' <summary>
    ''' DTO → Entity 変換
    ''' TimePatternDto → TimePatternEntity
    ''' </summary>
    Public Shared Function ToEntity(ByVal d As List(Of TimePatternDto)) As List(Of TimePatternEntity)
        Dim result As New List(Of TimePatternEntity)
        For i As Integer = 0 To d.Count - 1
            Dim e As New TimePatternEntity()
            e.Year = d(i).Year
            e.LectureDate = d(i).LectureDate
            e.Youbi = d(i).Youbi
            e.SchedulePattern = d(i).SchedulePattern
            e.CreateDate = d(i).CreateDate
            e.CreateUser = d(i).CreateUser
            e.UpdateDate = d(i).UpdateDate
            e.UpdateUser = d(i).UpdateUser
            result.Add(e)
        Next
        Return result
    End Function

End Class
