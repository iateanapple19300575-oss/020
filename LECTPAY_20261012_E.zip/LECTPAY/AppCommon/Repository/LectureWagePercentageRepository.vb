﻿Imports System.Data.SqlClient

Public Class LectureWagePercentageRepository
    Inherits TransactionBase

    Private _uow As DbTransactionScope

    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="uow"></param>
    Public Sub New(ByVal uow As DbTransactionScope)
        MyBase.New(uow)
        _uow = uow
    End Sub


    ''' <summary>
    ''' 指定された年度、月に一致するデータを取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function SearchByYearAndMonth(dto As LectureWagePercentageEntity) As List(Of LectureWagePercentageEntity)
        Dim sqlString As New System.Text.StringBuilder

        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Id").Append(" ")
        sqlString.Append("  , Year").Append(" ")
        sqlString.Append("  , Half_Year").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append("  , RowVersion").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("    ").Append(DBTableConst.TABLE_NAME_LECTURE_WAGE_PERCENTAGE).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Year = @Year").Append(" ")
        sqlString.Append("  AND Half_Year = @Half_Year").Append(" ")
        sqlString.Append("ORDER BY").Append(" ")
        sqlString.Append("  Year").Append(" ")
        sqlString.Append("  , Half_Year").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append(";")

        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Year", .Value = dto.Year})
        params.Add(New SqlParameter() With {.ParameterName = "@Half_Year", .Value = dto.HalfYear})

        Return ExecuteQuery(Of LectureWagePercentageEntity)(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' キー値指定による一意データを取得します。
    ''' </summary>
    ''' <returns></returns>
    Public Function FindByKey(dto As LectureWagePercentageEntity) As LectureWagePercentageEntity
        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("SELECT").Append(" ")
        sqlString.Append("  Id").Append(" ")
        sqlString.Append("  , Year").Append(" ")
        sqlString.Append("  , Half_Year").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append("  , RowVersion").Append(" ")
        sqlString.Append("FROM").Append(" ")
        sqlString.Append("  ").Append(DBTableConst.TABLE_NAME_LECTURE_WAGE_PERCENTAGE).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")

        Dim params As New List(Of SqlParameter)

        If Not dto.Id Is Nothing Then
            sqlString.Append("  AND Id = @Id").Append(" ")
            params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        Else
            sqlString.Append("  AND Year = @Year").Append(" ")
            sqlString.Append("  AND Half_Year = @Half_Year").Append(" ")
            sqlString.Append("  AND Site_Code = @Site_Code").Append(" ")
            sqlString.Append("  AND Grade = @Grade").Append(" ")
            sqlString.Append("  AND Class_Code = @Class_Code").Append(" ")
            params.Add(New SqlParameter() With {.ParameterName = "@Year", .Value = dto.Year})
            params.Add(New SqlParameter() With {.ParameterName = "@Half_Year", .Value = dto.HalfYear})
            params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = dto.SiteCode})
            params.Add(New SqlParameter() With {.ParameterName = "@Grade", .Value = dto.Grade})
            params.Add(New SqlParameter() With {.ParameterName = "@Class_Code", .Value = dto.ClassCode})
        End If

        Return ExecuteQuerySingle(Of LectureWagePercentageEntity)(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 1件追加
    ''' </summary>
    ''' <param name="dto">追加情報</param>
    ''' <returns></returns>
    Public Function Insert(dto As LectureWagePercentageEntity) As Integer
        Dim LWP = Tables.LectureWagePercentage

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("INSERT INTO").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("(").Append(" ")
        sqlString.Append("  Year").Append(" ")
        sqlString.Append("  , Half_Year").Append(" ")
        sqlString.Append("  , Site_Code").Append(" ")
        sqlString.Append("  , Grade").Append(" ")
        sqlString.Append("  , Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks").Append(" ")
        sqlString.Append("  , Create_Date").Append(" ")
        sqlString.Append("  , Create_User").Append(" ")
        sqlString.Append("  , Update_Date").Append(" ")
        sqlString.Append("  , Update_User").Append(" ")
        sqlString.Append(") VALUES (").Append(" ")
        sqlString.Append("  @Year").Append(" ")
        sqlString.Append("  , @Half_Year").Append(" ")
        sqlString.Append("  , @Site_Code").Append(" ")
        sqlString.Append("  , @Grade").Append(" ")
        sqlString.Append("  , @Class_Code").Append(" ")
        sqlString.Append("  , @Lecture_Coefficient").Append(" ")
        sqlString.Append("  , @Remarks").Append(" ")
        sqlString.Append("  , GETDATE()").Append(" ")
        sqlString.Append("  , @Create_User").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append("  , NULL").Append(" ")
        sqlString.Append(")").Append(" ")
        sqlString.Append(";").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Year", .Value = dto.Year})
        params.Add(New SqlParameter() With {.ParameterName = "@Half_Year", .Value = dto.HalfYear})
        params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = dto.SiteCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Grade", .Value = dto.Grade})
        params.Add(New SqlParameter() With {.ParameterName = "@Class_Code", .Value = dto.ClassCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Coefficient", .Value = dto.LectureCoefficient})
        params.Add(New SqlParameter() With {.ParameterName = "@Remarks", .Value = dto.Remarks})
        params.Add(New SqlParameter() With {.ParameterName = "@Create_User", .Value = dto.CreateUser})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 1件更新
    ''' </summary>
    ''' <param name="dto">更新情報</param>
    ''' <returns></returns>
    Public Function Update(dto As LectureWagePercentageEntity) As Integer
        Dim LWP = Tables.LectureWagePercentage

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("UPDATE").Append(" ")
        sqlString.Append("  " & LWP.TableName).Append(" ")
        sqlString.Append("SET").Append(" ")
        sqlString.Append("  Site_Code = @Site_Code").Append(" ")
        sqlString.Append("  , Grade = @Grade").Append(" ")
        sqlString.Append("  , Class_Code = @Class_Code").Append(" ")
        sqlString.Append("  , Lecture_Coefficient = @Lecture_Coefficient").Append(" ")
        sqlString.Append("  , Remarks = @Remarks").Append(" ")
        sqlString.Append("  , Update_Date = GETDATE()").Append(" ")
        sqlString.Append("  , Update_User = @Update_User").Append(" ")
        sqlString.Append("  WHERE").Append(" ")
        sqlString.Append("    1=1").Append(" ")
        sqlString.Append("    AND Id = @Id").Append(" ")
        sqlString.Append("    AND RowVersion = @RowVersion").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        params.Add(New SqlParameter() With {.ParameterName = "@Site_Code", .Value = dto.SiteCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Grade", .Value = dto.Grade})
        params.Add(New SqlParameter() With {.ParameterName = "@Class_Code", .Value = dto.ClassCode})
        params.Add(New SqlParameter() With {.ParameterName = "@Lecture_Coefficient", .Value = dto.LectureCoefficient})
        params.Add(New SqlParameter() With {.ParameterName = "@Remarks", .Value = dto.Remarks})
        params.Add(New SqlParameter() With {.ParameterName = "@Update_User", .Value = dto.UpdateUser})
        params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.RowVersion})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

    ''' <summary>
    ''' 削除
    ''' </summary>
    ''' <returns></returns>
    Public Function DeleteById(dto As LectureWagePercentageEntity) As Integer
        Dim LWP = Tables.LectureWagePercentage

        ' SQL文の生成
        Dim sqlString As New System.Text.StringBuilder
        sqlString.Length = 0
        sqlString.Append("DELETE").Append(" ")
        sqlString.Append("  FROM").Append(" ")
        sqlString.Append("    " & LWP.TableName).Append(" ")
        sqlString.Append("WHERE").Append(" ")
        sqlString.Append("  1=1").Append(" ")
        sqlString.Append("  AND Id = @Id").Append(" ")
        'sqlString.Append("  AND RowVersion = @RowVersion").Append(" ")

        ' パラメタ生成
        Dim params As New List(Of SqlParameter)
        params.Add(New SqlParameter() With {.ParameterName = "@Id", .Value = dto.Id})
        'params.Add(New SqlParameter() With {.ParameterName = "@RowVersion", .Value = dto.RowVersion})

        Return ExecuteNonQuery(sqlString.ToString(), params.ToArray)
    End Function

End Class
