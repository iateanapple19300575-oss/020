﻿''' <summary>
''' 控除種別バリデータ
''' 
''' 1:控除,2:前渡金,3:年調精算,4:健診・予防接種
''' </summary>
Public Class DeductionTypeValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' データ長
    ''' </summary>
    Private Const CODE_LENGTH As Integer = 1

    ''' <summary>
    ''' 最小値
    ''' </summary>
    Private Const MIN_VALUE As Integer = 1

    ''' <summary>
    ''' 最大値
    ''' </summary>
    Private Const MAX_VALUE As Integer = 4

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String =
                String.Format("{0}桁の半角数字(1, 2, 4のいずれか)で入力してください", CODE_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, CODE_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", CODE_LENGTH))
        End If

        ' 数字
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, "半角数字以外の値があります")
        End If

        ' 範囲チェック(3は欠番のためエラー)
        If Not ValidateChecker.IsNumberRange(value, MIN_VALUE, MAX_VALUE) OrElse value = "3" Then
            Return NewInvalidResult(value, "範囲外の値です")
        End If

        Return New ValidationItemResult With {.IsValid = True, .Value = value}
    End Function

End Class
