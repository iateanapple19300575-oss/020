﻿Imports System.Drawing

''' <summary>
''' コマバリデーション
''' </summary>
Public Class KomaValidator
    Inherits ValidatorAbstract

    ''' <summary>
    ''' コマデータ長
    ''' </summary>
    Private Const CODE_LENGTH As Integer = 1

    ''' <summary>
    ''' 概要メッセージ
    ''' </summary>
    ''' <returns></returns>
    Protected Overrides Property SummaryMessage As String = String.Format("{0}桁の半角数字（１～９）で入力してください", CODE_LENGTH)


    ''' <summary>
    ''' コンストラクタ
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <param name="isRequired"></param>
    Public Sub New(ByVal columnName As String, Optional ByVal isRequired As Boolean = False)
        MyBase.New(columnName, isRequired)
    End Sub

    ''' <summary>
    ''' 検証
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    Public Overrides Function Validate(ByVal value As String) As ValidationItemResult

        ' 必須
        If ValidateChecker.IsNullOrWhiteSpace(value) Then
            If (MyBase.IsRequired) Then
                Return NewInvalidResult(value, "値なし[必須項目]")
            Else
                Return New ValidationItemResult With {.IsValid = True, .Value = value}
            End If
        End If

        ' 半角
        If Not ValidateChecker.IsHalfWidthOnly(value, Me.IsRequired) Then
            Return NewInvalidResult(value, "全角文字の値があります")
        End If

        ' 桁数
        If Not ValidateChecker.IsFixedByteLengthRange(value, CODE_LENGTH) Then
            Return NewInvalidResult(value, String.Format("半角{0}桁以外です", CODE_LENGTH))
        End If

        ' 数字
        If Not ValidateChecker.IsHalfWidthNumberOnly(value) Then
            Return NewInvalidResult(value, "半角数字以外の文字があります")
        End If

        ' 範囲チェック
        If Not ValidateChecker.IsNumberRange(value, 1, 9) Then
            Return NewInvalidResult(value, "範囲外の値です")
        End If

        Return New ValidationItemResult With {.IsValid = True}
    End Function

End Class
