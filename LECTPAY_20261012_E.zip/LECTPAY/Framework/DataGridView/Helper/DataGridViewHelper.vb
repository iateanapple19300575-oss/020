﻿Imports System.Windows.Forms
''' <summary>
''' DataGridView の列設定を共通化するヘルパークラス。
''' ・列幅
''' ・表示名
''' ・非表示
''' ・書式
''' ・配置
''' を一括で適用する。
''' </summary>
Public Class DataGridViewHelper

    ''' <summary>
    ''' 指定された列定義リストを DataGridView に適用する。
    ''' </summary>
    Public Shared Sub ApplyColumnSettings(
        dgv As DataGridView,
        columns As List(Of DataGridViewColumnDefinition)
    )

        For Each colDef In columns
            If dgv.Columns.Contains(colDef.Name) Then
                Dim col = dgv.Columns(colDef.Name)

                col.HeaderText = colDef.HeaderText
                col.Width = colDef.Width
                col.Visible = colDef.Visible
                col.ReadOnly = colDef.ReadOnly
                col.DefaultCellStyle.Alignment = colDef.Alignment

                If Not String.IsNullOrEmpty(colDef.Format) Then
                    col.DefaultCellStyle.Format = colDef.Format
                End If
            End If
        Next

        dgv.AutoGenerateColumns = False
    End Sub

    ''' <summary>
    ''' DataGridView の DoubleBuffered を強制的に ON にする
    ''' </summary>
    Public Shared Sub EnableDoubleBuffer(ByVal dgv As DataGridView)
        Dim dgvType As Type = dgv.GetType()
        Dim prop = dgvType.GetProperty("DoubleBuffered",
            Reflection.BindingFlags.Instance Or
            Reflection.BindingFlags.NonPublic)

        prop.SetValue(dgv, True, Nothing)
    End Sub

    Public Shared Sub SetupFastGrid(ByVal dgv As DataGridView)
        With dgv
            .VirtualMode = True
            .AutoGenerateColumns = False

            ' AutoSize 完全禁止（最重要）
            .AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
            .AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None
            .ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing
            .RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing

            ' 行ヘッダー非表示（高速）
            .RowHeadersVisible = False

            ' 選択モード
            .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            .MultiSelect = False
        End With

        ' DoubleBuffered を有効化
        EnableDoubleBuffer(dgv)
    End Sub

    ''' <summary>
    ''' 指定した列名の中に選択されているセルがあるか判定します
    ''' </summary>
    Public Shared Function IsColumnCellSelected(dgv As DataGridView, columnName As String) As Boolean

        ' グリッドに指定した列が存在しない場合は、False
        If Not dgv.Columns.Contains(columnName) Then
            Return False
        End If

        ' 選択セルの中に指定列のセルがあるか判定
        Return dgv.SelectedCells.
                   Cast(Of DataGridViewCell)().
                   Any(Function(c) c.OwningColumn.Name = columnName)
    End Function

    ''' <summary>
    ''' 指定した列番号の中に選択されているセルがあるか判定します
    ''' </summary>
    Public Shared Function IsColumnCellSelected(dgv As DataGridView, columnIndex As Integer) As Boolean

        ' インデックスが範囲外の場合は、False
        If columnIndex < 0 OrElse columnIndex >= dgv.Columns.Count Then Return False

        ' 選択セルの中に指定列のセルがあるか判定
        Return dgv.SelectedCells.
                   Cast(Of DataGridViewCell)().
                   Any(Function(c) c.ColumnIndex = columnIndex)
    End Function

    ''' <summary>
    ''' 指定した複数のカラム名と値の条件（すべて前方一致）に合う行を検索し、スクロール・フォーカス（選択）を合わせます。
    ''' </summary>
    ''' <param name="targetControl">BeginInvokeを呼び出すためのコントロール（Formなど）</param>
    ''' <param name="dgv">対象のDataGridView</param>
    ''' <param name="searchConditions">検索条件（キー：カラム名、値：検索する先頭文字列）</param>
    Public Shared Sub RefreshAndFocusRow(targetControl As Control,
                                         dgv As DataGridView,
                                         searchConditions As Dictionary(Of String, Object))

        ' ガード節：未設定、または行や条件がない場合は何もしない
        If targetControl Is Nothing OrElse dgv Is Nothing OrElse dgv.Rows.Count = 0 OrElse searchConditions Is Nothing OrElse searchConditions.Count = 0 Then
            Exit Sub
        End If

        ' スレッドセーフに実行するためBeginInvokeを使用
        targetControl.BeginInvoke(New MethodInvoker(
            Sub()
                If dgv.Rows.Count = 0 Then Exit Sub

                ' 事前に指定されたすべてのカラムがDataGridViewに存在するかチェック
                For Each colName As String In searchConditions.Keys
                    If Not dgv.Columns.Contains(colName) Then
                        Throw New ArgumentException(String.Format("指定されたカラム名 '{0}' がDataGridViewに存在しません。", colName))
                    End If
                Next

                Dim targetRowIndex As Integer = -1

                ' 行をループ
                For i As Integer = 0 To dgv.Rows.Count - 1
                    Dim row As DataGridViewRow = dgv.Rows(i)

                    If Not row.IsNewRow Then
                        Dim isMatch As Boolean = True

                        ' 指定されたすべての条件に前方一致するかチェック（AND条件）
                        For Each kvp As KeyValuePair(Of String, Object) In searchConditions
                            Dim columnName As String = kvp.Key
                            Dim searchValue As Object = kvp.Value
                            Dim cellValue As Object = row.Cells(columnName).Value

                            ' 値がいずれもNothingでない場合
                            If cellValue IsNot Nothing AndAlso searchValue IsNot Nothing Then
                                Dim cellStr As String = ""

                                ' 対象セルが日付型（Date/DateTime）の場合のハンドリング
                                If TypeOf cellValue Is Date Then
                                    ' yyyy/MM/dd 形式の文字列に変換
                                    cellStr = DirectCast(cellValue, Date).ToString("yyyy/MM/dd")
                                Else
                                    cellStr = cellValue.ToString()
                                End If

                                Dim searchStr As String = searchValue.ToString()

                                ' 先頭から指定文字列に一致するか判定 (大文字・小文字を区別する設定)
                                If Not cellStr.StartsWith(searchStr, StringComparison.Ordinal) Then
                                    ' 一致しなければ、別の表現フォーマット（ハイフン区切り等）でもう一度だけ試す（日付型用補助）
                                    If TypeOf cellValue Is Date Then
                                        Dim cellStrHyphen As String = DirectCast(cellValue, Date).ToString("yyyy-MM-dd")
                                        If cellStrHyphen.StartsWith(searchStr, StringComparison.OrdinalIgnoreCase) Then
                                            Continue For ' マッチしたので次の条件チェックへ
                                        End If
                                    End If

                                    isMatch = False
                                    Exit For ' 1つでも不一致があればその行はスキップ
                                End If

                            ElseIf cellValue Is Nothing AndAlso searchValue Is Nothing Then
                                ' 両方Nothingなら一致とみなして継続
                            Else
                                ' 片方だけNothingなら不一致
                                isMatch = False
                                Exit For
                            End If
                        Next

                        ' すべての条件に前方一致した行が見つかった場合
                        If isMatch Then
                            targetRowIndex = i
                            Exit For ' 外側の行ループを抜ける
                        End If
                    End If
                Next

                ' 一致する行が見つからない場合は終了
                If targetRowIndex = -1 Then Exit Sub

                ' 表示されている最初のセルを取得（カレントセル設定時のエラー防止）
                Dim firstVisibleCell As DataGridViewCell = Nothing
                For Each cell As DataGridViewCell In dgv.Rows(targetRowIndex).Cells
                    If cell.Visible Then
                        firstVisibleCell = cell
                        Exit For
                    End If
                Next

                ' 画面更新・フォーカス処理
                dgv.FirstDisplayedScrollingRowIndex = targetRowIndex
                dgv.ClearSelection()
                dgv.Rows(targetRowIndex).Selected = True

                If firstVisibleCell IsNot Nothing Then
                    dgv.CurrentCell = firstVisibleCell
                End If

            End Sub))
    End Sub

    ''' <summary>
    ''' 【オーバーロード】単一のカラム条件で前方一致検索する場合の簡易メソッド
    ''' </summary>
    Public Shared Sub RefreshAndFocusRow(targetControl As Control, dgv As DataGridView, columnName As String, searchValue As Object)
        Dim conditions As New Dictionary(Of String, Object)()
        conditions.Add(columnName, searchValue)
        RefreshAndFocusRow(targetControl, dgv, conditions)
    End Sub

End Class